// import 'package:flutter/material.dart';
// import 'pyment.dart';

// class MyburgerDetails extends StatelessWidget {
//   final String name;
//   final String price;
//   const MyburgerDetails({
//     Key? key,
//     required String this.name,
//     required String this.price,
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//           backgroundColor: Colors.pinkAccent,
//           title: Center(
//             child: Text('Details of this Burger'),
//           )),
//       body: Center(
//         child: Container(
//           decoration: BoxDecoration(
//             image: DecorationImage(image: AssetImage("images/smoke.png",)),
//             gradient: LinearGradient(
//                 colors: [Color(0xffFC5495), Color(0xff5B0202)],
//                 begin: Alignment.topLeft,
//                 end: Alignment.centerRight),
//           ),
//           width: double.infinity,
//           height: double.infinity,
//           child: Column(
//             children: [
//               Padding(
//                 padding: const EdgeInsets.fromLTRB(0, 20, 0, 10),
//                 child: Image.asset(
//                   "images/burger1.png",
//                   height: 300,
//                   width: 300,
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(10.0),
//                 child: Text(
//                   name,
//                   style: TextStyle(
//                     fontSize: 32,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.white,
//                   ),
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(7),
//                 child: Text(
//                   "Price:",
//                   style: TextStyle(
//                     fontSize: 20,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.white,
//                   ),
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.fromLTRB(0, 5, 0, 20),
//                 child: Text(
//                   price,
//                   style: TextStyle(
//                     fontSize: 14,
//                     fontWeight: FontWeight.normal,
//                     color: Colors.yellow,
//                   ),
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.fromLTRB(0, 20, 0, 15),
//                 child: Text(
//                   "About the Company – Burger King India Limited",
//                   style: TextStyle(
//                     fontSize: 20,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.white,
//                   ),
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.fromLTRB(50, 15, 50, 30),
//                 child: Text(
//                   "The King Burger Bangladesh Ltd. (The King Burger), is a quick-service restaurant (QSR) chain. It was founded in 1954 in the U.S. and is owned by the Burger King Corporation. As of 30th Sept. 2020, the Burger King brand is the second-largest fast-food burger brand globally (based on the number of restaurants), with a global network of 18,675 restaurants in more than 100 countries and the U.S. territories. The Bangladeshi Franchise received the green flag by SEBI in January to go ahead with the initial public offering.",
//                   style: TextStyle(
//                     fontSize: 14,
//                     fontWeight: FontWeight.normal,
//                     color: Colors.white,
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 height: 50,
//                 width: 460,
//                 child: ElevatedButton(
//                     onPressed: () {
//                       Navigator.of(context).push(
//                           MaterialPageRoute(builder: (context) => Mypyment()));
//                     },
//                     style: ElevatedButton.styleFrom(
//                       primary: Colors.pink,
//                       onPrimary: Colors.white,
//                     ),
//                     child: Text(
//                       "Pyment method",
//                       style: TextStyle(
//                         fontSize: 20,
//                         fontWeight: FontWeight.bold,
//                         color: Colors.white,
//                       ),
//                     )),
//               ),
//               SizedBox(
//                 height: 10,
//               ),


//                   SizedBox(
//                 height: 50,
//                 width: 460,
//                 child: ElevatedButton(
//                     onPressed: () {
//                       Navigator.of(context).pop();
//                     },
//                     style: ElevatedButton.styleFrom(
//                       primary: Colors.pink[300],
//                       onPrimary: Colors.white,
//                     ),
//                     child: Text(
//                       "Go Back",
//                       style: TextStyle(
//                         fontSize: 20,
//                         fontWeight: FontWeight.bold,
//                         color: Colors.white,
//                       ),
//                     )),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
