import 'dart:html';

import 'package:flutter/material.dart';
import 'package:myhomework2/pyment.dart';
import 'Myburgerorderdetails.dart';

void main() => runApp(Myburger());

class Myburger extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Material App',
      home: Myburgerorderdetails(),
    );
  }
}

