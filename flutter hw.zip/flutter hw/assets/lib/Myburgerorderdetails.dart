import 'package:flutter/material.dart';
import 'pyment.dart';

class Myburgerorderdetails extends StatelessWidget {
  const Myburgerorderdetails({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(image: AssetImage("images/smoke.png",)),
            gradient: LinearGradient(
                colors: [Color(0xffFC5495), Color(0xff5B0202)],
                begin: Alignment.topLeft,
                end: Alignment.centerRight),
          ),
          width: double.infinity,
          height: double.infinity,
          child: Column(
            children: [
              Image.asset("images/burger2.png", ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text("Beef Masala King Burger", style: TextStyle( fontSize: 32, color: Colors.amber[300]),),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 15, 0, 5),
                child: Text("Price: (with VAT+ SD)", style: TextStyle( fontSize: 26, color: Colors.white),),
              ),
               Padding(
                padding: const EdgeInsets.all(5.0),
                child: Text("BDT 200 tk only (Bangladesh)", style: TextStyle( fontSize: 16, color: Colors.yellow),),
              ),
               Padding(
                padding: const EdgeInsets.fromLTRB(0, 30, 0, 5),
                child: Text("About this Burger", style: TextStyle( fontSize: 20, color: Colors.white),),
              ),
               Padding(
                padding: const EdgeInsets.fromLTRB(25, 5, 25, 5),
                child: Text("Per Serving: 480 calories; calories from fat 43%; protein 31g; fat 23g; saturated fat 5.6g; carbohydrates 37g; fiber 2.4g; sodium 978mg; cholesterol 127mg.", 
                style: TextStyle( fontSize: 16, color: Colors.cyan[200]),),
              ),

              Padding(
                padding: const EdgeInsets.fromLTRB(25, 5, 25, 30),
                child: Text("Beef is delicious on its own – it is a high-quality protein that is tender, juicy and full of natural flavor. You don’t need a bunch of mix-ins, or you’re just masking the flavor of the beef. Remember it’s not a meatloaf, but a burger. If you want to change up the flavor, do that with the amazing burger sauces below (you’ll want to try these!) and toppings. ",
                 style: TextStyle( fontSize: 16, color: Colors.white),
                ),
              ),
              SizedBox(
               height: 50,
              width: 460,
            child: ElevatedButton(
                onPressed: () {
                 Navigator.of(context).pop(MaterialPageRoute(builder: (context) => Mypyment()
                 ));
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.pink,
                  onPrimary: Colors.white,
                ),
                child: Text(
                  "Pyment",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                )),
          ),

          SizedBox(height: 10,),

          SizedBox(
            height: 50,
              width: 460,
            child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.pink[300],
                  onPrimary: Colors.white,
                ),
                child: Text(
                  "Go Back",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                )),
          ),
              
            ],
          ),
        ),
      ),
    );
  }
}
