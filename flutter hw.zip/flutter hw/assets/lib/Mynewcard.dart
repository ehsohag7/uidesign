import 'package:flutter/material.dart';
import 'myorder.dart';
import 'Myburgerorderdetails.dart';



class Mynewcard extends StatelessWidget {
  final String name;
  final String price;
  const Mynewcard({
    Key? key,
    required String this.name,
    required String this.price,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      elevation: 50,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(20))
          ),
      child: Container(
        height: 170,
        width: 150,
        child: Column(
          children: [
            Container(
                height: 80,
                width: double.infinity,
                color: Colors.pink,
                child: Image.asset(
                  "images/splash.png",
                  height: 100,
                  width: 100,
                )),
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 5, 0, 10),
              child: Container(
                child: Text(
                  name,
                  style: TextStyle(
                    color: Colors.deepOrange,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
              child: Container(
                child: Text(
                  price,
                  style: TextStyle(
                    color: Color(0xff081F32),
                    fontSize: 10,
                    fontWeight: FontWeight.normal,
                  ),
                ),
              ),
            ),
            SizedBox(
              child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => Myburgerorderdetails()));
                  },
                  style: ElevatedButton.styleFrom(
                    primary: Colors.pink,
                    onPrimary: Colors.white,
                  ),
                  child: Text(
                    "Order now",
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  )),
            ),
          ],
        ),
      ),
    );
  }
}
