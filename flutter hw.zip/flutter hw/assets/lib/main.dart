import 'package:flutter/material.dart';
import 'myone.dart';

void main() => runApp(Myhomework2());

class Myhomework2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Material App',
      home: burgerapp(),
    );
  }
}

