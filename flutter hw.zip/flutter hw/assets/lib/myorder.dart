// import 'package:flutter/material.dart';
// import 'Myburger.dart';

// void main() => runApp(Myorder());

// class Myorder extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: 'Material App',
//       home: MyburgerDetails(
//         name: "Chicken Burger",
//         price: "BDT: 200tk (Bangladesh)",
//       ),
//     );
//   }
// }
