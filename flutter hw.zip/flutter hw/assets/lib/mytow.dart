import 'package:flutter/material.dart';
import 'Mynewcard.dart';

void main() => runApp(Mytwo());

class Mytwo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Material App',
      home: Scaffold(
          body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [Color(0xffFC5495), Color(0xff5B0202)],
              begin: Alignment.topLeft,
              end: Alignment.centerRight),
        ),
        width: double.infinity,
        height: double.infinity,
        child: Column(
          children: [
            Image.asset(
              "images/burger_banner2.png",
              height: 212,
              width: double.infinity,
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Text(
                "Let you feel like a king",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(11.0),
              child: Container(
                child: Row(
                  children: [
                    Mynewcard(
                      name: "Chicken Burger",
                      price: "BDT 200 tk only",
                    ),
                    Mynewcard(
                      name: "Beef Burger",
                      price: "BDT 250 tk only",
                    ),
                    Mynewcard(
                      name: "Beef Masala Burger",
                      price: "BDT 300 tk only",
                    ),
                    
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(11.0),
              child: Container(
                child: Row(
                  children: [
                    Mynewcard(
                      name: "Chicken Burger",
                      price: "BDT 200 tk only",
                    ),
                    Mynewcard(
                      name: "Beef Burger",
                      price: "BDT 250 tk only",
                    ),
                    Mynewcard(
                      name: "Beef Masala Burger",
                      price: "BDT 300 tk only",
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(11.0),
              child: Container(
                child: Row(
                  children: [
                    Mynewcard(
                      name: "Chicken Burger",
                      price: "BDT 200 tk only",
                    ),
                    Mynewcard(
                      name: "Beef Burger",
                      price: "BDT 250 tk only",
                    ),
                    Mynewcard(
                      name: "Beef Masala Burger",
                      price: "BDT 300 tk only",
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: SizedBox(
                height: 50,
                width: 460,
                child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Colors.pink,
                      onPrimary: Colors.white,
                    ),
                    child: Text(
                      "Go Back",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    )),
              ),
            ),
          ],
        ),
      )),
    );
  }
}
