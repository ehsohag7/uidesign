import 'package:flutter/material.dart';

void main() => runApp(Mypyment());

class Mypyment extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Material App',
      home: Scaffold(
        appBar: AppBar(
            backgroundColor: Colors.pinkAccent,
            title: Center(
              child: Text('Pyment now'),
            )),
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: [Color(0xffFC5495), Color(0xff5B0202)],
                begin: Alignment.topLeft,
                end: Alignment.centerRight),
          ),
          width: double.infinity,
          height: double.infinity,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 50, 0, 10),
                child: Text(
                  "Pyment this order",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 0, 10),
                child: Text(
                  "Select your option",
                  style: TextStyle(
                    color: Colors.yellowAccent,
                    fontSize: 16,
                    fontWeight: FontWeight.normal,
                  ),
                ),
              ),
              SizedBox(
                height: 50,
                width: 460,
                child: ElevatedButton(
                    onPressed: () {
                      // Navigator.of(context).push(MaterialPageRoute(builder: (context) => Mypyment()
                      // ));
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Colors.pink,
                      onPrimary: Colors.white,
                    ),
                    child: Text(
                      "Confirm",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    )),
              ),
              SizedBox(height: 10,),
              

                  SizedBox(
                height: 50,
                width: 460,
                child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop()
                      ;
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Colors.pink[300],
                      onPrimary: Colors.white,
                    ),
                    child: Text(
                      "Go Back",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    )),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
