import 'package:flutter/material.dart';
import 'mytow.dart';
import 'loginpage.dart';

class signup extends StatelessWidget {
  const signup({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      decoration: BoxDecoration(
        image: DecorationImage(image: AssetImage("images/smoke.png",)),
        gradient: LinearGradient(
            colors: [Color(0xffFC5495), Color(0xff5B0202)],
            begin: Alignment.topLeft,
            end: Alignment.centerRight),
      ),
      width: double.infinity,
      height: double.infinity,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(00, 80, 00, 10),
            child: Image.asset(
              "images/splash.png",
              width: 500,
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(50, 10, 50, 5),
            child: TextField(
              style: TextStyle(color: Colors.white, fontSize: 16),
              decoration: InputDecoration(
                fillColor: Colors.transparent,
                filled: true,
                hintStyle: (TextStyle(
                  color: Colors.pink[200],
                  fontSize: 14,
                )),
                hintText: "Full name",
              ),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(50, 10, 50, 5),
            child: TextField(
              style: TextStyle(color: Colors.white, fontSize: 16),
              decoration: InputDecoration(
                fillColor: Colors.transparent,
                filled: true,
                hintStyle: (TextStyle(
                  color: Colors.pink[200],
                  fontSize: 14,
                )),
                hintText: "Email",
              ),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(50, 10, 50, 5),
            child: TextField(
              style: TextStyle(color: Colors.white, fontSize: 16),
              decoration: InputDecoration(
                fillColor: Colors.transparent,
                filled: true,
                hintStyle: (TextStyle(
                  color: Colors.pink[200],
                  fontSize: 14,
                )),
                hintText: "Create Password",
              ),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(50, 10, 50, 5),
            child: TextField(
              style: TextStyle(color: Colors.white, fontSize: 16),
              decoration: InputDecoration(
                fillColor: Colors.transparent,
                filled: true,
                hintStyle: (TextStyle(
                  color: Colors.pink[200],
                  fontSize: 14,
                )),
                hintText: "Re-Password",
              ),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Container(
            child: Column(
              children: [
                SizedBox(
                  height: 40,
                  width: 400,
                  child: ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).push(
                            MaterialPageRoute(builder: (context) => Mytwo()));
                      },
                      style: ElevatedButton.styleFrom(
                        primary: Colors.pink,
                        onPrimary: Colors.white,
                      ),
                      child: Text(
                        "Sing up",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      )),
                ),
                SizedBox(
                  height: 20,
                  width: 50,
                ),
                SizedBox(
                  height: 40,
                  width: 400,
                  child: ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => loginpage()));
                      },
                      style: ElevatedButton.styleFrom(
                        primary: Colors.pink[300],
                        onPrimary: Colors.white,
                      ),
                      child: Text(
                        "Log in",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      )),
                ),
              ],
            ),
          )
        ],
      ),
    ));
  }
}
